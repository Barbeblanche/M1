TP - Threads

Le but du TP est de paralléliser une recherche dans un vecteur d'entier. Pour cela nous devons créer des threads et leur donner une partie du tableau sur laquelle chercher la valeur donnée.
Nous n'avons pas réussi à finir le TP correctement : il y a un problème au niveau de l'affichage.
